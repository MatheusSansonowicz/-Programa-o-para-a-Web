package com.example.projetoaula20032025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projetoaula20032025ApplicationTests {

    @Test
    void contextLoads() {
    }

}
