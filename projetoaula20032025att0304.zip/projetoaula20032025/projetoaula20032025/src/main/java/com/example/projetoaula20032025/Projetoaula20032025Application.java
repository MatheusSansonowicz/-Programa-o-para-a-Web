package com.example.projetoaula20032025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projetoaula20032025Application {

    public static void main(String[] args) {
        SpringApplication.run(Projetoaula20032025Application.class, args);
    }

}
