package com.example.projetoaula20032025.dto;

import com.example.projetoaula20032025.classesPadrao.User;

public record dtoPhone(Long id, String number, User user) {

}

