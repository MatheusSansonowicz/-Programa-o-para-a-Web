package com.example.trabalho1pweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabalho1PWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
