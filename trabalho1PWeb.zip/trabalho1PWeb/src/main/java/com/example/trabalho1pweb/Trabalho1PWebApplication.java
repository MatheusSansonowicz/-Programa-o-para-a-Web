package com.example.trabalho1pweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trabalho1PWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(Trabalho1PWebApplication.class, args);
    }

}
