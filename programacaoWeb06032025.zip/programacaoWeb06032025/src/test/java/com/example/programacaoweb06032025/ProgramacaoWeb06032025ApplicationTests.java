package com.example.programacaoweb06032025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgramacaoWeb06032025ApplicationTests {

    @Test
    void contextLoads() {
    }

}
