package com.example.programacaoweb06032025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgramacaoWeb06032025Application {

    public static void main(String[] args) {
        SpringApplication.run(ProgramacaoWeb06032025Application.class, args);
    }

}
